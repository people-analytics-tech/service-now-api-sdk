class ITSMException(Exception):
    pass
